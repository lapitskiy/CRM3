from django.views.generic import ListView
from .models import Storehouses

class StorehouseHomeView(ListView):
    model = Storehouses
    paginate_by = 2
    template_name = 'storehouse/stores_list.html'
    context_object_name = 'storehouse'
    related_module_name = 'storehouse'  # mixin

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Все склады'
        return context