from django.apps import AppConfig


class StorehouseConfig(AppConfig):
    name = 'storehouse'
