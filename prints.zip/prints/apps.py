from django.apps import AppConfig


class PrintConfig(AppConfig):
    name = 'prints'
    verbose_name = 'Печать'