from django.apps import AppConfig


class MoneyConfig(AppConfig):
    name = 'money'
    verbose_name = 'Бухгалтерия'